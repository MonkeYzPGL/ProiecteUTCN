
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XsiO xsio = new XsiO();
	}
}
