import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;


public class XsiO implements ActionListener
{
	
	Random random = new Random(); //index folosit pentru aflarea primei miscari
	
	JFrame tablou = new JFrame("X si 0"); //frame-ul proiectului
	JLabel eticheta = new JLabel(); //eticheta
	JLabel eticheta1 = new JLabel(); //eticheta pentru nume
	JPanel titlu = new JPanel(); //titlul proiectului
	JPanel butonPanou = new JPanel(); //panoul cu butoane
	JButton[] butoane = new JButton[25]; 
	JButton reset = new JButton();
	boolean jucator; //variabila pentru a decide care jucator joaca
	
	
	public XsiO() //constructorul
	{
		tablou.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //inchiderea frame-ului
		tablou.setSize(800,800); //marimea frame-ului la lansare
		tablou.getContentPane().setBackground(new Color(100,100,100)); //culoare background frame
		tablou.setLayout(new BorderLayout()); 
		tablou.setVisible(true); //pt a se afisa frame-ul
		
		eticheta.setBackground(new Color(21,96,189)); //culoare background eticheta
		eticheta.setForeground(new Color(0,0,0));
		eticheta.setFont(new Font("Forte", Font.ITALIC,50)); //tipul scrisului
		eticheta.setHorizontalAlignment(JLabel.CENTER);
		eticheta.setText("X si 0");
		eticheta.setOpaque(true);
		
		eticheta1.setBackground(Color.WHITE);
		eticheta1.setForeground(new Color(255,255,255));
		eticheta1.setFont(new Font("Times New Roman",Font.ITALIC,20));
		eticheta1.setHorizontalAlignment(JLabel.RIGHT);
		eticheta1.setText("Elecfi Sergiu-Andrei");
		
		butonPanou.setLayout(new GridLayout(5,5));
		butonPanou.setBackground(new Color(160,160,160));
		
		titlu.setLayout(new BorderLayout());
		titlu.setBounds(0,0,800,50); 
		
		for(int i = 0; i < 25; i++)
		{
			butoane[i] = new JButton(); //cream fiecare buton in parte
			butonPanou.add(butoane[i]); //adaugam fiecare buton in panou
			butoane[i].setFont(new Font("Times New Roman",Font.BOLD,100));
			butoane[i].setFocusable(false);
			butoane[i].addActionListener(this);
			butoane[i].setBackground(new Color(255,165,0));
		}
		titlu.add(eticheta); // adaugam in titlu labelul
		tablou.add(titlu,BorderLayout.NORTH); //adaugam titlul pe frame
		tablou.add(eticheta1,BorderLayout.SOUTH);
		tablou.add(butonPanou);
		
		primaMiscare();
		
	}

	
	public void primaMiscare() //metoda in care alegem prima miscare
	{
		try
		{
			Thread.sleep(2500); //asteapta 10 secunde pentru inceperea jocului dupa rularea programului
		} 
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		if(random.nextInt(2) == 0)
		{
			jucator = true;
			eticheta.setText("Randul lui X"); //afisam randul cui este sus in eticheta
		}
		else
		{
			eticheta.setText("Randul lui 0"); //la fel ca mai sus
			jucator = false;
		}
	}
	
	public void verificare()  //metoda in care verificam winner-ul
	{
		//verificare daca X castiga
		if((butoane[0].getText()=="X") && (butoane[1].getText()=="X") && (butoane[2].getText()=="X") && (butoane[3].getText()=="X") && (butoane[4].getText()=="X") ) //randul 1
		{
			xCastiga(0,1,2,3,4);
		}
		if((butoane[5].getText()=="X") && (butoane[6].getText()=="X") && (butoane[7].getText()=="X") && (butoane[8].getText()=="X") && (butoane[9].getText()=="X") ) //randul 2
		{
			xCastiga(5,6,7,8,9);
		}
		if((butoane[10].getText()=="X") && (butoane[11].getText()=="X") && (butoane[12].getText()=="X") && (butoane[13].getText()=="X") && (butoane[14].getText()=="X") ) //randul 3
		{
			xCastiga(10,11,12,13,14);
		}
		if((butoane[15].getText()=="X") && (butoane[16].getText()=="X") && (butoane[17].getText()=="X") && (butoane[18].getText()=="X") && (butoane[19].getText()=="X") ) //randul 4
		{
			xCastiga(15,16,17,18,19);
		}
		if((butoane[20].getText()=="X") && (butoane[21].getText()=="X") && (butoane[22].getText()=="X") && (butoane[23].getText()=="X") && (butoane[24].getText()=="X") ) //randul 5
		{
			xCastiga(20,21,22,23,24);
		}
		if((butoane[0].getText()=="X") && (butoane[6].getText()=="X") && (butoane[12].getText()=="X") && (butoane[18].getText()=="X") && (butoane[24].getText()=="X") ) //diagonala principala
		{
			xCastiga(0,6,12,18,24);
		}
		if((butoane[4].getText()=="X") && (butoane[8].getText()=="X") && (butoane[12].getText()=="X") && (butoane[16].getText()=="X") && (butoane[20].getText()=="X") ) //diagonala secundara
		{
			xCastiga(4,8,12,16,20);
		}
		if((butoane[0].getText()=="X") && (butoane[5].getText()=="X") && (butoane[10].getText()=="X") && (butoane[15].getText()=="X") && (butoane[20].getText()=="X") ) //coloana1
		{
			xCastiga(0,5,10,15,20);
		}
		if((butoane[1].getText()=="X") && (butoane[6].getText()=="X") && (butoane[11].getText()=="X") && (butoane[16].getText()=="X") && (butoane[21].getText()=="X") ) //coloana2
		{
			xCastiga(1,6,11,16,21);
		}
		if((butoane[2].getText()=="X") && (butoane[7].getText()=="X") && (butoane[12].getText()=="X") && (butoane[17].getText()=="X") && (butoane[22].getText()=="X") ) //coloana2
		{
			xCastiga(2,7,12,17,22);
		}
		if((butoane[3].getText()=="X") && (butoane[8].getText()=="X") && (butoane[13].getText()=="X") && (butoane[18].getText()=="X") && (butoane[23].getText()=="X") ) //coloana2
		{
			xCastiga(3,8,13,18,23);
		}
		if((butoane[4].getText()=="X") && (butoane[9].getText()=="X") && (butoane[14].getText()=="X") && (butoane[19].getText()=="X") && (butoane[24].getText()=="X") ) //coloana2
		{
			xCastiga(4,9,43,19,24);
		}
		
		
		//jucatorul 0 castiga
		if((butoane[0].getText()=="0") && (butoane[1].getText()=="0") && (butoane[2].getText()=="0") && (butoane[3].getText()=="0") && (butoane[4].getText()=="0") ) //randul 1
		{
			oCastiga(0,1,2,3,4);
		}
		if((butoane[5].getText()=="0") && (butoane[6].getText()=="0") && (butoane[7].getText()=="0") && (butoane[8].getText()=="0") && (butoane[9].getText()=="0") ) //randul 2
		{
			oCastiga(5,6,7,8,9);
		}
		if((butoane[10].getText()=="0") && (butoane[11].getText()=="0") && (butoane[12].getText()=="0") && (butoane[13].getText()=="0") && (butoane[14].getText()=="0") ) //randul 3
		{
			oCastiga(10,11,12,13,14);
		}
		if((butoane[15].getText()=="0") && (butoane[16].getText()=="0") && (butoane[17].getText()=="0") && (butoane[18].getText()=="0") && (butoane[19].getText()=="0") ) //randul 4
		{
			oCastiga(15,16,17,18,19);
		}
		if((butoane[20].getText()=="0") && (butoane[21].getText()=="0") && (butoane[22].getText()=="0") && (butoane[23].getText()=="0") && (butoane[24].getText()=="0") ) //randul 5
		{
			oCastiga(20,21,22,23,24);
		}
		if((butoane[0].getText()=="0") && (butoane[6].getText()=="0") && (butoane[12].getText()=="0") && (butoane[18].getText()=="0") && (butoane[24].getText()=="0") ) //diagonala principala
		{
			oCastiga(0,6,12,18,24);
		}
		if((butoane[4].getText()=="0") && (butoane[8].getText()=="0") && (butoane[12].getText()=="0") && (butoane[16].getText()=="0") && (butoane[20].getText()=="0") ) //diagonala secundara
		{
			oCastiga(4,8,12,16,20);
		}
		if((butoane[0].getText()=="0") && (butoane[5].getText()=="0") && (butoane[10].getText()=="0") && (butoane[15].getText()=="0") && (butoane[20].getText()=="0") ) //coloana1
		{
			oCastiga(0,5,10,15,20);
		}
		if((butoane[1].getText()=="0") && (butoane[6].getText()=="0") && (butoane[11].getText()=="0") && (butoane[16].getText()=="0") && (butoane[21].getText()=="0") ) //coloana2
		{
			oCastiga(1,6,11,16,21);
		}
		if((butoane[2].getText()=="0") && (butoane[7].getText()=="0") && (butoane[12].getText()=="0") && (butoane[17].getText()=="0") && (butoane[22].getText()=="0") ) //coloana2
		{
			oCastiga(2,7,12,17,22);
		}
		if((butoane[3].getText()=="0") && (butoane[8].getText()=="0") && (butoane[13].getText()=="0") && (butoane[18].getText()=="0") && (butoane[23].getText()=="0") ) //coloana2
		{
			oCastiga(3,8,13,18,23);
		}
		if((butoane[4].getText()=="0") && (butoane[9].getText()=="0") && (butoane[14].getText()=="0") && (butoane[19].getText()=="0") && (butoane[24].getText()=="0") ) //coloana2
		{
			oCastiga(4,9,43,19,24);
		}
		
		boolean toate = true;
		for(int i = 0; i < 25; i++)
		{
			if(butoane[i].getText()!="0" && butoane[i].getText()!="X")
			{
				toate = false;
			}
		}
		if(toate == true)
		{
			egalitate();
		}
	}
	
	public void xCastiga(int a, int b, int c, int d, int e)  //metoda cand X castiga
	{
		//COloram casutele castigatoare
		butoane[a].setBackground(new Color(0, 235, 0));
		butoane[b].setBackground(new Color(0, 235, 0));
		butoane[c].setBackground(new Color(0, 235, 0));
		butoane[d].setBackground(new Color(0, 235, 0));
		butoane[e].setBackground(new Color(0, 235, 0));
		
		//Inchidem toate celelalte casute
		for(int i = 0; i < 25; i++)
		{
			butoane[i].setEnabled(false);
		}
		butoane[12].setText("R");
		butoane[12].setEnabled(true);
		butoane[12].setBackground(Color.RED);
		eticheta.setText("Jucatorul X a castigat");
	}
	
	public void oCastiga(int a, int b, int c, int d, int e) //metoda cand 0 castiga
	{
		//COloram casutele castigatoare
		butoane[a].setBackground(new Color(0, 235, 0));
		butoane[b].setBackground(new Color(0, 235, 0));
		butoane[c].setBackground(new Color(0, 235, 0));
		butoane[d].setBackground(new Color(0, 235, 0));
		butoane[e].setBackground(new Color(0, 235, 0));

		//Inchidem toate celelalte casute
		for(int i = 0; i < 25; i++)
		{
			butoane[i].setEnabled(false);
		}
		butoane[12].setText("R");
		butoane[12].setEnabled(true);
		butoane[12].setBackground(Color.RED);
		eticheta.setText("Jucatorul 0 a castigat");
	}

	public void egalitate()
	{
		eticheta.setText("Egalitate");
		for(int i = 0; i < 25; i++)
		{
			butoane[i].setEnabled(false);
		}
		butoane[12].setText("R");
		butoane[12].setEnabled(true);
		butoane[12].setBackground(Color.RED);
	}
	
	public void restart()
	{
		for(int i =0; i < 25; i++)
		{
			butoane[i].setText("");
			butoane[i].setEnabled(true);
			butoane[i].setBackground(new Color(255,165,0));
		}
		primaMiscare();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		for(int i = 0; i < 25; i++)
		{
			if(e.getSource() == butoane[i])
			{
				//verificam daca este randul lui X
				if(jucator == true)
				{
					//verificam daca casuta apasata este libera
					if(butoane[i].getText() =="")
					{
						butoane[i].setForeground(new Color(8, 255, 8)); //culoarea lui X
						butoane[i].setText("X"); //scriem X-ul
						jucator = false; //trecem la celalalt jucator
						eticheta.setText("Randul lui 0");
						verificare(); //verificam daca s-a castigat
					}
					if(butoane[i].getText() == "R")
					{
						restart();
					}
				}
				else
				{
					//verificam daca casuta apasata este libera
					if(butoane[i].getText() =="")
					{
						butoane[i].setForeground(new Color(255, 8, 8)); //culoarea lui 0
						butoane[i].setText("0"); //scriem 0-ul
						jucator = true;//trecem la celalalt jucator
						eticheta.setText("Randul lui X"); 
						verificare(); //verificam daca s-a castigat
					}
					if(butoane[i].getText() == "R")
					{
						restart();
					}
				}
			}
		}
	}
	
	
}
